document.getElementById('cadastroForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const data = {
    nome: this.nome.value,
    instituicao: this.instituicao.value,
    curso: this.curso.value,
    ano: this.ano.value
  };
  localStorage.setItem('usuario', JSON.stringify(data));
  window.location.href = 'minha-conta.html';
});
